#!/bin/bash

if [ "$#" -ne 1 ]; then
    "You need to specify the namespace: $0 <namespace>"
    exit 1
fi

namespace=$1
secret_name=gcrsecret
account_name=kavach-service-account


kubectl create namespace ${namespace}

kubectl -n ${namespace} create secret docker-registry ${secret_name} \
  --docker-username=_json_key \
  --docker-password="$(cat service-key.json )" \
  --docker-server=gcr.io \
  --docker-email=example@example.com

kubectl -n ${namespace} create serviceaccount ${account_name}

kubectl -n ${namespace} get serviceaccounts ${account_name} -o json |\
  jq "del(.metadata.resourceVersion)" |\
  jq "setpath([\"imagePullSecrets\"];[{\"name\":\"${secret_name}\"}])" |\
  kubectl -n ${namespace} replace serviceaccount ${account_name} -f -
