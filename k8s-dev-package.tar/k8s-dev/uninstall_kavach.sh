#!/bin/bash

echo "**********************************************************************"
echo "**************** Kavach Security Mesh Uninstallation *****************"
echo "**********************************************************************"

set -o errexit
set -o nounset
set -o pipefail
set -o errtrace

CLIENT_CHART_NAME="client-1.0.0"

CLIENT_NAMESPACE="kavach-system"

function delete_release {
  chart_name=$1
  release_name=$(helm ls | grep "${chart_name}" | awk '{ print $1 }')
  if [[ -z "${release_name}" ]]
  then
    echo "No release for chart ${chart_name}"
    exit 1
  fi
  helm delete --purge "${release_name}"
}

function delete_crds {
  component=$1
  kubectl delete crd --selector "kavach=${component}"
}

function get_all_namespaces {
  kubectl get namespaces -o jsonpath='{range .items[*]}{.metadata.name} {end}'
}

function remove_kavach_pull_secret_from_all_namespaces {
  for ns in $(get_all_namespaces); do
    kubectl -n "${ns}" delete --ignore-not-found secret kavach-service-key
  done
}

delete_release ${CLIENT_CHART_NAME}
kubectl delete namespace ${CLIENT_NAMESPACE}

delete_crds vcenter
delete_crds sidecar-injector
remove_kavach_pull_secret_from_all_namespaces
