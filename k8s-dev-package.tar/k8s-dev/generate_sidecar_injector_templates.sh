#!/bin/bash

set -o errexit

function print_help {
    echo "Script usage: $0 -s <static values file> -d <dynamic values file> -D <deployment values file> -o <output dir>"
}

STATIC_CONFIG=""
DYNAMIC_CONFIG=""
DEPLOYMENT_CONFIG=""
OUTPUT_DIR="kavach-client-install-templates"
while getopts "hs:d:o:D:" i; do
    case "${i}" in
        h)
            print_help
            exit 0
            ;;
        s)
            STATIC_CONFIG=${OPTARG}
            ;;
        d)
            DYNAMIC_CONFIG=${OPTARG}
            ;;
        D)
            DEPLOYMENT_CONFIG=${OPTARG}
            ;;
        o)
            OUTPUT_DIR=${OPTARG}
            ;;
        *)
            print_help
            exit 1
            ;;
    esac
done

if [[ -z "${STATIC_CONFIG}" ]] || [[ -z "${DYNAMIC_CONFIG}" ]] || [[ -z "${OUTPUT_DIR}" ]] || [[ -z "${DEPLOYMENT_CONFIG}" ]]
then
  echo "values missing"
  print_help
  exit 1
fi

# Create output directory for generated files.
mkdir -p "${OUTPUT_DIR}"

echo "Generating kavach services templates."
helm template sidecar-injector-1.0.0.tgz \
  --values "${STATIC_CONFIG}" \
  --values "${DYNAMIC_CONFIG}" \
  --values "${DEPLOYMENT_CONFIG}" \
  --set vcenter.cluster=false > "${OUTPUT_DIR}"/002_sidecar-injector-1.0.0.yaml
