#!/bin/bash -x

function print_help {
    echo "Script usage: $0 [-v <vcenter_values_path>] [-p <package_directory>] [-d <deployment_type>]"
}

VCENTER_VALUES_PATH=""
PACKAGE_DIR="."
DEPLOYMENT_TYPE="${DEPLOYMENT_TYPE:-small}"
while getopts "hv:p:d:" o; do
    case "${o}" in
        h)
            print_help
            exit 0
            ;;
        v)
            VCENTER_VALUES_PATH=${OPTARG}
            ;;
        p)
            PACKAGE_DIR=${OPTARG}
            ;;
        d)
            DEPLOYMENT_TYPE=${OPTARG}
            ;;
        *)
            print_help
            exit 1
            ;;
    esac
done

case "${DEPLOYMENT_TYPE}" in
    dev|small|medium|large) ;;
    *)
        echo "Expected dev, small, medium, or large depoyment type while got: ${DEPLOYMENT_TYPE}"
        exit 1
        ;;
esac

source "${PACKAGE_DIR}/kavach_k8s_helpers.sh"

# Destroy any pre-existing K8s cluster.
__k8s_cluster_destroy

# Create a new K8s cluster.
__k8s_cluster_setup

#
# Install Kavach adapter.
#

# Setup Helm.
cd ${PACKAGE_DIR}
sudo KUBECONFIG=/etc/kubernetes/admin.conf kubectl -n kube-system create serviceaccount tiller
sudo KUBECONFIG=/etc/kubernetes/admin.conf kubectl create clusterrolebinding tiller --clusterrole cluster-admin --serviceaccount=kube-system:tiller
sudo /snap/bin/helm init --service-account=tiller --wait

# Install Kavach adapter components.
deploy_args=(-s static.yaml -d values.yml -D "client-${DEPLOYMENT_TYPE}-values.yaml")
if [[ -n "$VCENTER_VALUES_PATH" ]]
then
    deploy_args=("${deploy_args[@]}" -V vcenter.yaml)
fi
sudo ./deploy-client.sh "${deploy_args[@]}"
echo "Kavach Mesh Adapter install: DONE"
