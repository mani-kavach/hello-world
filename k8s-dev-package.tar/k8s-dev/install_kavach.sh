#!/bin/bash

echo "**********************************************************************"
echo "**************** Kavach Security Mesh Installation *******************"
echo "**********************************************************************"

set -o errexit
set -o nounset
set -o pipefail
set -o errtrace

function print_help {
    echo "Script usage: $0 [-v <vcenter_values_path>] [-t] [-d <deployment_type]"
    echo "-v - installation for vcenter"
    echo "-t - helmless installation using templates or sets default path to generate templates"
    echo "-T - helmless installation using templates with custom path or sets custom path to generate templates."
    echo "-g - generate templates only (must be used with -t or -T option to provide path to generate templates)"
}

if [[ `kubectl auth can-i add roles` == "no" || `kubectl auth can-i add rolebindings` == "no" || `kubectl auth can-i change serviceaccount` == "no" ]]
then
    echo "Kavach security mesh installation requires cluster admin privileges. Please re-run the script with a user account that has appropriate rights."
    echo "Please check documentation for more info: https://kubernetes.io/docs/reference/access-authn-authz/rbac/#service-account-permissions"
    exit 1
fi

DEPLOYMENT_TYPE="${DEPLOYMENT_TYPE:-small}"
VCENTER_VALUES_PATH=""
CLIENT_INSTALL_TEMPLATE_DIR=""
GENERATE_TEMPLATES="${GENERATE_TEMPLATES:-}"
while getopts "htT:gv:" o; do
    case "${o}" in
        h)
            print_help
            exit 0
            ;;
        d)
            DEPLOYMENT_TYPE=${OPTARG}
            ;;
        v)
            VCENTER_VALUES_PATH=${OPTARG}
            ;;
        T)
            CLIENT_INSTALL_TEMPLATE_DIR=${OPTARG}
            ;;
        t)
            CLIENT_INSTALL_TEMPLATE_DIR="kavach-client-install-templates"
            ;;
        g)
            GENERATE_TEMPLATES=true
            ;;
        *)
            print_help
            exit 1
        ;;
    esac
done

case "${DEPLOYMENT_TYPE}" in
    dev|small|medium|large) ;;
    *)
        echo "Expected dev, small, medium, or large deployment type while got: ${DEPLOYMENT_TYPE}"
        exit 1
        ;;
esac

deploy_args=(-s static.yaml -d values.yml -D "client-${DEPLOYMENT_TYPE}-values.yaml")

if [[ -n "${CLIENT_INSTALL_TEMPLATE_DIR}" ]]
then
    deploy_args=(${deploy_args[@]} -t)
else
    if [[ `helm version --server` ]]
    then
        echo "Helm already installed"
    else
        echo "Helm initialization on k8s cluster"
        ./helm_init.sh
        echo "Helm initialization complete"
    fi
fi

if [[ -n "${VCENTER_VALUES_PATH}" ]]
then
    deploy_args=(${deploy_args[@]} -V "../${VCENTER_VALUES_PATH}")
fi
./deploy-client.sh "${deploy_args[@]}"
