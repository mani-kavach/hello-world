#!/bin/bash

echo "**********************************************************************"
echo "**************** Kavach Security Mesh Installation *******************"
echo "**********************************************************************"

set -o errexit
set -o nounset
set -o pipefail
set -o errtrace

function print_help {
    echo "Script usage: $0 [-t] [-T <yaml_template_directory>] [-g] [-d <deployment_type]"
    echo "-t - helmless installation using templates or sets default path to generate templates"
    echo "-T - helmless installation using templates with custom path or sets custom path to generate templates."
    echo "-g - generate templates only (must be used with -t or -T option to provide path to generate templates)"
}

DEPLOYMENT_TYPE="${DEPLOYMENT_TYPE:-small}"
CLIENT_INSTALL_TEMPLATE_DIR=""
GENERATE_TEMPLATES="${GENERATE_TEMPLATES:-}"
while getopts "htT:gv:" o; do
    case "${o}" in
        h)
            print_help
            exit 0
            ;;
        d)
            DEPLOYMENT_TYPE=${OPTARG}
            ;;
        v)
            # This option is ignored.
            # Kept for compatibility with deploy-client.sh
            ;;
        T)
            CLIENT_INSTALL_TEMPLATE_DIR=${OPTARG}
            ;;
        t)
            CLIENT_INSTALL_TEMPLATE_DIR="kavach-client-install-templates"
            ;;
        g)
            GENERATE_TEMPLATES=true
            ;;
        *)
            print_help
            exit 1
        ;;
    esac
done

case "${DEPLOYMENT_TYPE}" in
    dev|small|medium|large) ;;
    *)
        echo "Expected dev, small, medium, or large deployment type while got: ${DEPLOYMENT_TYPE}"
        exit 1
        ;;
esac

echo "Checking if cluster supports MutatingWebhooks"
kubectl get mutatingwebhookconfigurations.admissionregistration.k8s.io >/dev/null 2>/dev/null || (echo "MutatingWebhooks not supported. Aborting" && exit 1)

echo "Checking permissions"
if [[ `kubectl auth can-i create csr` == "no" || `kubectl auth can-i approve csr` == "no" || `kubectl auth can-i delete csr` == "no" ]]
then
    "Kavach sidecar injector installation requires privileges to create, approve and delete CSRs. Aborting."
    exit 1
fi

deploy_args=(-s static.yaml -d values.yml -D "client-${DEPLOYMENT_TYPE}-values.yaml")

if [[ -n "${CLIENT_INSTALL_TEMPLATE_DIR}" ]]
then
    deploy_args=(${deploy_args[@]} -t)
else
    if [[ `helm version --server` ]]
    then
        echo "Helm already installed"
    else
        echo "Helm initialization on k8s cluster"
        ./helm_init.sh
        echo "Helm initialization complete"
    fi
fi

./deploy-sidecar-injector.sh "${deploy_args[@]}"
