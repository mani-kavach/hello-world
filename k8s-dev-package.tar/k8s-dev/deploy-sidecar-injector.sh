#!/bin/bash

# The deploy-sidecar-injector.sh script is not intended to be called on its own,
# unless you know what you are doing. Instead, it should be invoked via
# `install_sidecar_injector.sh` script.
#
# The deploy-sidecar-injector.sh script assumes that the K8s cluster is already
# prepared and the `kubectl` config is pointing to it. Also, Kavach mesh components
# should be already installed. If you want to use Helm it should be initialized
# on the cluster (the Tiller is installed).
#
# The deploy-sidecar-injector.sh script resposibilities are:
# 1. Prepare the values/arguments for installation
# 2. Invoke the installation via Helm or generate the YAML files and then use
# them with `kubectl -f`
# 3. Create and sign certificates needed by the webhook
# If the `-o` option is provided, the generated YAMLs are not applied to the
# cluster and the certs are not created.

set -o errexit
set -o nounset
set -o pipefail
set -o errtrace

function print_help {
    echo "Script usage: $0 -s <static_config_file> -d <dynamic_config_file> -D <deployment_values_file> [-t] [-o] [-T <yaml_template_directory>]"
    echo "-t - Deploy kavach client components from YAML templates stored in default directory (i.e ./kavach-client-install-templates) or sets default path to generate templates."
    echo "-T - Deploy kavach client components from YAML templates stored in custom directory or sets custom path to generate templates."
    echo "-o - Generate templates only (must be used with -t or -T option to provide path to generate templates)"
}

STATIC_VALUES_FILE=""
DYNAMIC_VALUES_FILE=""
DEPLOYMENT_VALUES_FILE=""
CLIENT_INSTALL_TEMPLATE_DIR=""
ONLY_GENERATE=false
while getopts "htos:d:V:T:D:" o; do
    case "${o}" in
        h)
            print_help
            exit 0
            ;;
        s)
            STATIC_VALUES_FILE=${OPTARG}
            ;;
        d)
            DYNAMIC_VALUES_FILE=${OPTARG}
            ;;
        D)
            DEPLOYMENT_VALUES_FILE=${OPTARG}
            ;;
        V)
            # This option is ignored.
            # Kept for compatibility with deploy-client.sh
            ;;
        T)
            CLIENT_INSTALL_TEMPLATE_DIR=${OPTARG}
            ;;
        t)
            CLIENT_INSTALL_TEMPLATE_DIR="kavach-client-install-templates"
            ;;
        o)
            ONLY_GENERATE=true
            ;;
        *)
           print_help
           exit 1
           ;;
    esac
done

if [[ -z "${STATIC_VALUES_FILE}" ]] || [[ -z "${DYNAMIC_VALUES_FILE}" ]] || [[ -z "${DEPLOYMENT_VALUES_FILE}" ]]
then
  print_help
  exit 1
fi

function create_webhook_cert() {
  ./create_webhook_signed_cert.sh --service kavach-sidecar-injector \
    --secret kavach-sidecar-injector-cert --namespace kavach-system
}

function deploy_yaml() {
  echo "Client Template Install Directory: ${CLIENT_INSTALL_TEMPLATE_DIR}"
  echo "Generate Kavach adapter YAML templates"
  ./generate_sidecar_injector_templates.sh \
    -s "${STATIC_VALUES_FILE}" \
    -d "${DYNAMIC_VALUES_FILE}" \
    -D "${DEPLOYMENT_VALUES_FILE}" \
    -o "${CLIENT_INSTALL_TEMPLATE_DIR}"

  if [[ ${ONLY_GENERATE} == true ]]
  then
    echo "Skipping installation as -o flag is set"
    exit 0
  fi

  create_webhook_cert
  echo "Installing Kavach security mesh components from yaml templates."
  kubectl create -f ${CLIENT_INSTALL_TEMPLATE_DIR}/002_sidecar-injector-1.0.0.yaml
  cat mutatingwebhook.yaml | ./patch_webhook_ca_bundle.sh | kubectl apply -f -
}

function deploy_helm() {
  echo "Installing Kavach security mesh components through helm."
  create_webhook_cert

  echo "Installing Kavach sidecar injector."
  helm install sidecar-injector-1.0.0.tgz --wait --timeout 900 \
    --values "${STATIC_VALUES_FILE}" \
    --values "${DYNAMIC_VALUES_FILE}" \
    --values "${DEPLOYMENT_VALUES_FILE}"
  cat mutatingwebhook.yaml | ./patch_webhook_ca_bundle.sh | kubectl apply -f -
}

# If yaml template directory is configured proceed to install Kavach security mesh
# using template files. If not, fallback to helm based install.
if [[ -n ${CLIENT_INSTALL_TEMPLATE_DIR} ]]
then
    deploy_yaml
else
    deploy_helm
fi
