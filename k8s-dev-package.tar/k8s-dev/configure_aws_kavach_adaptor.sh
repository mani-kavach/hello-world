#!/bin/bash

set -o nounset
set -o pipefail
set -o errtrace


function must_exist { 
    export PATH=$PATH:$HOME/.local/bin
    command -v $1 >/dev/null 2>&1 
    if [ $? != 0 ]; then
        echo -e >&2 $1 is not installed but required! $2 Aborting!
        exit 1
    fi
}

msg="yq utility is needed by this script. You could try installing using:\n
sudo apt-get update; sudo apt install -y python-pip; pip install yq;\nexport PATH=$PATH:$HOME/.local/bin\n"

must_exist "yq" "${msg}"

msg="jq utility is needed by this script. You could try installing using:\n
sudo apt-get update; sudo apt-get install -y jq\n"

must_exist "jq" "${msg}"
AWS_CFG_FILE=vcenter.yaml

echo "Setting up AWS environment:"
echo -n "Enter VPC id: "
read vpc_id
vpc_id=\"$vpc_id\"
echo -n "Enter VPC region: "
read vpc_region
vpc_region=\"$vpc_region\"

unset access_token;
echo -n "Enter AWS access key id: "
while IFS= read -r -s -n1 aws_access_token; do
  if [[ -z $aws_access_token ]]; then
     echo
     break
  else
     echo -n '*'
     access_token+=$aws_access_token
  fi
done
access_token=$(echo -n $access_token | base64)
access_token=\"$access_token\"

unset access_key;
echo -n "Enter AWS access secret key: "
while IFS= read -r -s -n1 aws_access_key; do
  if [[ -z $aws_access_key ]]; then
     echo
     break
  else
     echo -n '*'
     access_key+=$aws_access_key
  fi
done
access_key=$(echo -n $access_key | base64)
access_key=\"$access_key\"

dummy_val=$(echo -ne default | base64)
dummy_val=\"$dummy_val\"

if [[ "${vpc_id}" == '""' ]] || [[ "${vpc_region}" == '""' ]] || [[ "${access_token}" == '""' ]] || [[ "${access_key}" == '""' ]];
then
        echo "ABORT: Configuration values cannot be empty/skipped. Please rerun with valid config"
        exit 1
fi

cat $AWS_CFG_FILE | /home/ubuntu/.local/bin/yq . > ./tmp_cfg.json
jq -s ".[0].vcenter_connector.configmap.aws.vpcs=$vpc_id | \
       .[0].vcenter_connector.configmap.aws.region=$vpc_region | \
       .[0].vcenter_connector.configmap.aws.zone=\"\"| \
       .[0].vcenter_connector.configmap.vmware.vcenter=$dummy_val | \
       .[0].vcenter_connector.configmap.vmware.datacenter=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.username=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.password=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.ssh=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.name=\"vmw-prod-us1-vm-cred\" | \
       .[0].vcenter_connector.secrets.vc.ssh=$dummy_val | \
       .[0].vcenter_connector.secrets.vc.name=\"vmw-prod-us1-cred\" | \
       .[0].vcenter_connector.secrets.vc.username=$dummy_val | \
       .[0].vcenter_connector.secrets.vc.password=$dummy_val | \
       .[0].vcenter_connector.secrets.aws.name=\"aws-prod-us1-cred\" | \
       .[0].vcenter_connector.secrets.aws.accesskey=$access_token | \
       .[0].vcenter_connector.secrets.aws.secretaccesskey=$access_key | .[0]" ./tmp_cfg.json | /home/ubuntu/.local/bin/yq . -y > $AWS_CFG_FILE

# Remove prior service files only if found.
if (systemctl -q is-active kavach-adapter-standalone-init.service); then
    systemctl stop kavach-adapter-standalone-init.service
    systemctl disable kavach-adapter-standalone-init.service
    systemctl daemon-reload
    systemctl reset-failed
fi

./install_kavach_adapter.sh
echo -n "Installing Kavach Mesh Adapter ."
until service kavach-adapter-standalone-init status | grep "Kavach Mesh Adapter install: DONE"
do
     echo -n "."
     sleep 4
done
echo "DONE"

exit 0
