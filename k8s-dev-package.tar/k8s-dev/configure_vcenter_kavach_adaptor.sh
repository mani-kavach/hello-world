#!/bin/bash

set -o nounset
set -o pipefail
set -o errtrace


function must_exist { 
    export PATH=$PATH:$HOME/.local/bin
    command -v $1 >/dev/null 2>&1 
    if [ $? != 0 ]; then
        echo -e >&2 $1 is not installed but required! $2 Aborting!
        exit 1
    fi
}

msg="yq utility is needed by this script. You could try installing using:\n
sudo apt-get update; sudo apt install -y python-pip; pip install yq;\nexport PATH=$PATH:$HOME/.local/bin\n"

must_exist "yq" "${msg}"

msg="jq utility is needed by this script. You could try installing using:\n
sudo apt-get update; sudo apt-get install -y jq\n"

must_exist "jq" "${msg}"

VCENTER_CFG_FILE=vcenter.yaml

echo "Setting up VMware vCenter environment:"
echo -n "Enter vCenter IP Address/Hostname: "
read vcenter_host
vcenter_host=\"$vcenter_host\"
echo -n "Enter Datacenter Name: "
read datacenter_name
datacenter_name=\"$datacenter_name\"
echo -n "Enter vCenter Username: "
read -r vcenter_username
vcenter_username=$(echo -n $vcenter_username | base64)
vcenter_username=\"$vcenter_username\"

unset vcenter_password;
echo -n "Enter vCenter Password: "
while IFS= read -r -s -n1 vc_pass; do
  if [[ -z $vc_pass ]]; then
     echo
     break
  else
     echo -n '*'
     vcenter_password+=$vc_pass
  fi
done
vcenter_password=$(echo -n $vcenter_password | base64)
vcenter_password=\"$vcenter_password\"

dummy_val=$(echo -ne default | base64)
dummy_val=\"$dummy_val\"

if [[ "${vcenter_host}" == '""' ]] || [[ "${datacenter_name}" == '""' ]] || [[ "${vcenter_username}" == '""' ]] || [[ "${vcenter_password}" == '""' ]];
then
        echo "ABORT: Configuration values cannot be empty/skipped. Please rerun with valid config"
        exit 1
fi

cat $VCENTER_CFG_FILE | /home/ubuntu/.local/bin/yq . > ./tmp_cfg.json
jq -s ".[0].vcenter_connector.configmap.vmware.vcenter=$vcenter_host | \
       .[0].vcenter_connector.configmap.vmware.datacenter=$datacenter_name | \
       .[0].vcenter_connector.configmap.aws.vpcs=\"\"| \
       .[0].vcenter_connector.configmap.aws.region=\"\"| \
       .[0].vcenter_connector.configmap.aws.zone=\"\"| \
       .[0].vcenter_connector.secrets.vm.username=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.password=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.ssh=$dummy_val | \
       .[0].vcenter_connector.secrets.vm.name=\"vmw-prod-us1-vm-cred\" | \
       .[0].vcenter_connector.secrets.aws.accesskey=$dummy_val | \
       .[0].vcenter_connector.secrets.aws.secretaccesskey=$dummy_val | \
       .[0].vcenter_connector.secrets.aws.name=\"aws-prod-us1-cred\" | \
       .[0].vcenter_connector.secrets.vc.ssh=$dummy_val | \
       .[0].vcenter_connector.secrets.vc.name=\"vmw-prod-us1-cred\" | \
       .[0].vcenter_connector.secrets.vc.username=$vcenter_username | \
       .[0].vcenter_connector.secrets.vc.password=$vcenter_password | .[0]" ./tmp_cfg.json | /home/ubuntu/.local/bin/yq . -y > $VCENTER_CFG_FILE

# Remove prior service files only if found.
if (systemctl -q is-active kavach-adapter-standalone-init.service); then
    systemctl stop kavach-adapter-standalone-init.service
    systemctl disable kavach-adapter-standalone-init.service
    systemctl daemon-reload
    systemctl reset-failed
fi

./install_kavach_adapter.sh
echo -n "Installing Kavach Mesh Adapter ."
until service kavach-adapter-standalone-init status | grep "Kavach Mesh Adapter install: DONE"
do
     echo -n "."
     sleep 4
done
echo "DONE"

exit 0
