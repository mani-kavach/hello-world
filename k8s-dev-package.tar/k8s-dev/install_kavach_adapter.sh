#!/bin/bash

echo "**********************************************************************"
echo "**************** Kavach Security Mesh Installation *******************"
echo "**********************************************************************"

set -o errexit
set -o nounset
set -o pipefail
set -o errtrace

function print_help {
    echo "Script usage: $0"
}

while getopts "h:" o; do
    case "${o}" in
        h)
            print_help
            exit 0
            ;;
        *)
            print_help
            exit 1
            ;;
    esac
done

# Install packages needed by Kavach.
sudo apt-get update
sudo apt install -y jq docker.io apt-transport-https curl
sudo snap install helm --classic
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
sudo bash -c "cat >/etc/apt/sources.list.d/kubernetes.list" <<'EOF'
deb http://apt.kubernetes.io/ kubernetes-xenial main
EOF
sudo apt-get update
sudo apt-get install -y kubelet=1.14.0-00 kubeadm=1.14.0-00 kubectl=1.14.0-00

# Enable Kavach adapter service.
sudo sed -i "s:INSTALL_DIR:-p $PWD:g" ./kavach-adapter-standalone-init.service
sudo sed -i "s:VCENTER_OPTS:-v vcenter.yaml:g" ./kavach-adapter-standalone-init.service
sudo mkdir -p /etc/kavach
sudo cp ./kavach-adapter-standalone-init.service /etc/systemd/system
sudo cp ./kavach_adapter_standalone_setup.sh /etc/kavach
sudo systemctl enable kavach-adapter-standalone-init.service
sudo systemctl restart kavach-adapter-standalone-init.service
