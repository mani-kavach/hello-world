#!/bin/bash

echo "**********************************************************************"
echo "************** Kavach Sidecar Injector Uninstallation ****************"
echo "**********************************************************************"

set -o errexit
set -o nounset
set -o pipefail
set -o errtrace

CLIENT_CHART_NAME="sidecar-injector-1.0.0"

CLIENT_NAMESPACE="kavach-system"

function delete_release {
  chart_name=$1
  release_name=$(helm ls | grep "${chart_name}" | awk '{ print $1 }')
  if [[ -z "${release_name}" ]]
  then
    echo "No release for chart ${chart_name}"
    exit 1
  fi
  helm delete --purge "${release_name}"
}

delete_release ${CLIENT_CHART_NAME}
kubectl delete MutatingWebhookConfiguration kavach-sidecar-injector || true
